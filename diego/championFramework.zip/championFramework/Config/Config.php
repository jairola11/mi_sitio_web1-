<?php

    //define("BASE_URL","http://localhost/champion-framework/");
    const BASE_URL = "http://localhost/champion-framework/";

    //Datos de conexión a Base de Datos
	const CONNECTION = false;
	const DB_HOST = "localhost";
	const DB_NAME = "db_sistema";
	const DB_USER = "root";
	const DB_PASSWORD = "";
	const DB_CHARSET = "utf8";





?>